
import { GoogleGenAI, Modality, GenerateContentResponse } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const imageModel = 'gemini-2.5-flash-image';
const textModel = 'gemini-2.5-flash';

export interface TimeTravelResult {
  imageUrl: string;
  description: string;
}

/**
 * Extracts the image data URL from a Gemini response.
 * @param response The response from the Gemini API.
 * @returns A data URL string or null if not found.
 */
const extractImageUrl = (response: GenerateContentResponse): string | null => {
    // Safely access parts using optional chaining to prevent crash if content is missing (e.g., safety block)
    const parts = response.candidates?.[0]?.content?.parts;
    if (parts) {
        for (const part of parts) {
            if (part.inlineData) {
                const base64ImageBytes = part.inlineData.data;
                const mimeType = part.inlineData.mimeType;
                return `data:${mimeType};base64,${base64ImageBytes}`;
            }
        }
    }
    return null;
};


export const generateTimeTravelImage = async (
  base64Image: string,
  mimeType: string,
  decade: string
): Promise<TimeTravelResult> => {
  try {
    // --- Step 1: Generate the time-traveled image ---
    const imageGenerationPrompt = `Transformeer de persoon op de foto in een zeer realistisch, stijlvol portret uit de ${decade}. De mode, haarstijl en sfeer moeten perfect overeenkomen met het tijdperk.`;

    const originalImagePart = {
      inlineData: {
        data: base64Image,
        mimeType: mimeType,
      },
    };

    const imageResponse = await ai.models.generateContent({
      model: imageModel,
      contents: {
        parts: [originalImagePart, { text: imageGenerationPrompt }],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    const imageUrl = extractImageUrl(imageResponse);

    if (!imageUrl) {
      const finishReason = imageResponse.candidates?.[0]?.finishReason;
      console.error("Image generation failed. Finish reason:", finishReason, "Response:", imageResponse);
      let errorMessage = "The AI failed to generate a new image.";
      if (finishReason === 'SAFETY') {
          errorMessage = "Image generation was blocked for safety reasons. This can sometimes happen with photos of people. Please try a different image.";
      } else {
          errorMessage += " Please try a different photo or decade.";
      }
      throw new Error(errorMessage);
    }

    // --- Step 2: Generate a description for the new image ---
    // Extract base64 and mimeType from the new data URL for the next API call
    const [meta, newImageBase64] = imageUrl.split(',');
    const newImageMimeType = meta.match(/:(.*?);/)?.[1];

    if (!newImageBase64 || !newImageMimeType) {
        throw new Error("Could not process the newly generated image.");
    }
    
    const descriptionGenerationPrompt = `Dit is een foto die is gestyled om eruit te zien alsof hij in de ${decade} is genomen. Schrijf een korte, pakkende beschrijving (hoofdtekst) in één paragraaf die de stijl en de sfeer van de foto beschrijft, alsof het een bijschrift uit een modeblad uit die tijd is.`;
    
    const newImagePart = {
        inlineData: {
            data: newImageBase64,
            mimeType: newImageMimeType,
        }
    }

    const descriptionResponse = await ai.models.generateContent({
        model: textModel, // Use a text-focused model
        contents: { parts: [newImagePart, { text: descriptionGenerationPrompt }]},
    });

    const description = descriptionResponse.text;
    
    if (!description) {
        // Fallback description if the API fails to generate one
        return { imageUrl, description: `A stylish portrait from the ${decade}.` };
    }

    return { imageUrl, description };

  } catch (error) {
    console.error("Error in time travel generation process:", error);
    if (error instanceof Error) {
        throw new Error(error.message || "An unexpected error occurred during image generation.");
    }
    throw new Error("Failed to generate image. Please try again.");
  }
};
