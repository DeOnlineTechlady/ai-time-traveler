
import React, { useState, useCallback, useMemo } from 'react';
import { DECADES } from './constants';
import { generateTimeTravelImage, TimeTravelResult } from './services/geminiService';

// --- Helper Functions ---
const fileToBase64 = (file: File): Promise<{ base64: string; mimeType: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      const [mimeString, base64] = result.split(',');
      const mimeType = mimeString.match(/:(.*?);/)?.[1];
      if (base64 && mimeType) {
        resolve({ base64, mimeType });
      } else {
        reject(new Error('Failed to parse file data.'));
      }
    };
    reader.onerror = (error) => reject(error);
  });
};


// --- SVG Icons ---
const CameraIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.528 1.718a.75.75 0 01.162.819A8.97 8.97 0 009 6a9 9 0 009 9 8.97 8.97 0 004.463-.69a.75.75 0 01.82.161l1.406 1.406a.75.75 0 01.022 1.044l-1.406 1.406a.75.75 0 01-1.044.022A8.97 8.97 0 0018 15a9 9 0 00-9-9 8.97 8.97 0 00-.69 4.463a.75.75 0 01.161.82l1.406 1.406a.75.75 0 011.044.022l1.406-1.406a.75.75 0 01.022-1.044A8.97 8.97 0 0015 9a9 9 0 00-9-9 8.97 8.97 0 00-4.463.69a.75.75 0 01-.82-.161L-.193 8.034a.75.75 0 01-.022-1.044L.92 5.584a.75.75 0 011.044-.022A8.97 8.97 0 006 3a9 9 0 009 9 8.97 8.97 0 00.69-4.463a.75.75 0 01-.161-.82L14.124.962a.75.75 0 01-.022-1.044L15.508-.488a.75.75 0 011.044-.022A8.97 8.97 0 0021 6a9 9 0 00-9-9 8.97 8.97 0 00-4.463-.69a.75.75 0 01-.82.161L5.23 8.307a.75.75 0 01-.022 1.044l1.406 1.406a.75.75 0 011.044.022A8.97 8.97 0 0012 12a9 9 0 00-9-9 8.97 8.97 0 00-3.69 4.463a.75.75 0 01.161.82l1.406 1.406a.75.75 0 011.044.022l1.406-1.406a.75.75 0 01.022-1.044A8.97 8.97 0 009 6a9 9 0 00-9-9" />
    </svg>
);


// --- UI Components ---
interface ImageUploaderProps {
  onImageUpload: (file: File) => void;
  previewUrl: string | null;
  disabled: boolean;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, previewUrl, disabled }) => {
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onImageUpload(file);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <label
        htmlFor="file-upload"
        className={`relative block w-full h-64 border-2 border-dashed rounded-lg cursor-pointer transition-colors duration-300 ${
          disabled ? 'cursor-not-allowed bg-zinc-900/50' : 'border-zinc-700 hover:border-[#FE0074] hover:bg-zinc-900/50'
        } ${previewUrl ? 'border-solid border-[#FE0074]' : ''}`}
      >
        {previewUrl ? (
          <img src={previewUrl} alt="Preview" className="object-cover w-full h-full rounded-lg" />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-zinc-400">
            <CameraIcon className="w-16 h-16 mb-2" />
            <span className="font-semibold">Upload a photo</span>
            <span className="text-sm">PNG, JPG, WEBP</span>
          </div>
        )}
        <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/png, image/jpeg, image/webp" disabled={disabled}/>
      </label>
    </div>
  );
};


interface DecadeSelectorProps {
  selectedDecade: string;
  onDecadeChange: (decade: string) => void;
  disabled: boolean;
}

const DecadeSelector: React.FC<DecadeSelectorProps> = ({ selectedDecade, onDecadeChange, disabled }) => (
    <div className="flex flex-wrap justify-center gap-2 md:gap-3 my-8">
        {DECADES.map((decade) => (
            <button
                key={decade}
                type="button"
                onClick={() => onDecadeChange(decade)}
                disabled={disabled}
                className={`px-4 py-2 text-sm md:text-base font-semibold rounded-full transition-all duration-300 transform hover:scale-105 disabled:cursor-not-allowed disabled:opacity-50 ${
                    selectedDecade === decade
                        ? 'bg-[#FE0074] text-white shadow-lg shadow-[#FE0074]/30'
                        : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                }`}
            >
                {decade}
            </button>
        ))}
    </div>
);


interface ResultCardProps {
    originalImageUrl: string;
    generatedResult: TimeTravelResult;
    decade: string;
}

const ResultCard: React.FC<ResultCardProps> = ({ originalImageUrl, generatedResult, decade }) => (
    <div className="w-full max-w-6xl mx-auto mt-12 bg-zinc-900/50 backdrop-blur-sm rounded-2xl shadow-2xl p-6 md:p-8 animate-fade-in border border-zinc-800">
        <div className="grid md:grid-cols-5 gap-8 items-start">
            <div className="md:col-span-2">
                <h3 className="text-lg font-bold text-zinc-300 mb-3 text-center">Original</h3>
                <img src={originalImageUrl} alt="Original" className="rounded-lg w-full aspect-square object-cover shadow-lg" />
            </div>
            <div className="md:col-span-3">
                 <h3 className="text-lg font-bold text-[#FE0074] mb-3 text-center">{decade}</h3>
                <img src={generatedResult.imageUrl} alt={`Generated for ${decade}`} className="rounded-lg w-full aspect-square object-cover shadow-lg" />
            </div>
        </div>
        <div className="mt-8 pt-6 border-t border-zinc-800">
             <p className="text-zinc-300 italic text-center text-lg">"{generatedResult.description}"</p>
        </div>
    </div>
);

const Loader: React.FC<{ decade: string }> = ({ decade }) => (
  <div className="flex flex-col items-center justify-center text-center text-white mt-10">
    <div className="relative w-24 h-24">
        <div className="absolute inset-0 border-4 border-t-[#FE0074] border-zinc-800 rounded-full animate-spin"></div>
        <div className="w-full h-full flex items-center justify-center">
            <SparklesIcon className="w-10 h-10 text-[#FE0074] animate-pulse" />
        </div>
    </div>
    <h2 className="mt-4 text-xl font-semibold tracking-wider">Time Traveling...</h2>
    <p className="text-zinc-400">Hold on tight, we're heading to the {decade}!</p>
  </div>
);


// --- Main App Component ---
export default function App() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedDecade, setSelectedDecade] = useState<string>(DECADES[4]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<TimeTravelResult | null>(null);

  const previewUrl = useMemo(() => {
    if (selectedFile) {
      return URL.createObjectURL(selectedFile);
    }
    return null;
  }, [selectedFile]);

  const handleImageUpload = useCallback((file: File) => {
    setSelectedFile(file);
    setResult(null); // Clear previous result on new image upload
    setError(null);
  }, []);

  const handleGenerateClick = async () => {
    if (!selectedFile) {
      setError("Please upload an image first.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const { base64, mimeType } = await fileToBase64(selectedFile);
      const generatedResult = await generateTimeTravelImage(base64, mimeType, selectedDecade);
      setResult(generatedResult);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const isButtonDisabled = !selectedFile || isLoading;

  return (
    <div className="min-h-screen bg-black text-white p-4 sm:p-6 lg:p-8 font-sans bg-grid-zinc-800/[0.05]">
      <div className="absolute inset-0 -z-10 h-full w-full bg-black bg-[radial-gradient(#333_1px,transparent_1px)] [background-size:16px_16px]"></div>
      <main className="container mx-auto max-w-5xl py-8">
        <header className="text-center mb-10">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#FE0074]">
            AI Time Traveler
          </h1>
          <p className="mt-3 text-lg text-zinc-400 max-w-2xl mx-auto">
            See yourself through the decades. Upload a photo, pick an era, and let AI work its magic.
          </p>
        </header>

        <div className="w-full p-6 md:p-8 bg-zinc-900/40 backdrop-blur-md border border-zinc-800 rounded-2xl shadow-2xl">
          <ImageUploader onImageUpload={handleImageUpload} previewUrl={previewUrl} disabled={isLoading} />
          
          <DecadeSelector selectedDecade={selectedDecade} onDecadeChange={setSelectedDecade} disabled={isLoading} />

          <div className="text-center">
            <button
              onClick={handleGenerateClick}
              disabled={isButtonDisabled}
              className="inline-flex items-center justify-center px-8 py-4 text-lg font-bold text-white bg-[#FE0074] border border-transparent rounded-full shadow-lg transition-all duration-300 transform hover:scale-105 hover:bg-[#d60063] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#FE0074] focus:ring-offset-black disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100"
            >
              <SparklesIcon className="w-6 h-6 mr-3" />
              Time Travel!
            </button>
          </div>
        </div>

        {error && <div className="mt-8 text-center text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</div>}

        {isLoading && <Loader decade={selectedDecade} />}

        {result && previewUrl && (
          <ResultCard originalImageUrl={previewUrl} generatedResult={result} decade={selectedDecade}/>
        )}
      </main>

      <footer className="text-center py-8 mt-12 text-zinc-500 text-sm">
        <p>Powered by Gemini. Create your own reality.</p>
      </footer>
    </div>
  );
}
